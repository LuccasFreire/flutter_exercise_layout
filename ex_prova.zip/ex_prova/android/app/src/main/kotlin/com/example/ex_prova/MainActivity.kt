package com.example.ex_prova

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
